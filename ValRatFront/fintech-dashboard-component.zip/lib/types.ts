export type AssetType = 'stock' | 'etf' | 'fii' | 'crypto' | 'fixed'

export interface Asset {
  id: string
  ticker: string
  name: string
  type: AssetType
  quantity: number
  averagePrice: number
  currentPrice: number
  totalInvested: number
  currentValue: number
  profitLoss: number
  percentChange: number
}

export interface Transaction {
  id: string
  type: 'buy' | 'sell' | 'dividend' | 'deposit' | 'withdraw'
  ticker?: string
  assetType?: AssetType
  amount: number
  quantity?: number
  price?: number
  date: string
  status: 'success' | 'pending' | 'failed'
}

export interface PortfolioAllocation {
  type: AssetType
  label: string
  totalInvested: number
  currentValue: number
  percentage: number
}

export interface PortfolioData {
  totalBalance: number
  totalInvested: number
  profitLoss: number
  percentChange: number
  assets: Asset[]
  transactions: Transaction[]
  allocations: PortfolioAllocation[]
  historicalData: { date: string; value: number }[]
}

export const assetTypeLabels: Record<AssetType, string> = {
  stock: 'Ações',
  etf: 'ETFs',
  fii: 'FIIs',
  crypto: 'Cripto',
  fixed: 'Renda Fixa'
}

export const assetTypeColors: Record<AssetType, string> = {
  stock: 'bg-chart-1',
  etf: 'bg-chart-2',
  fii: 'bg-chart-3',
  crypto: 'bg-chart-4',
  fixed: 'bg-chart-5'
}
