import type { PortfolioData, Asset, Transaction, PortfolioAllocation } from './types'

const generateHistoricalData = () => {
  const data = []
  const baseValue = 85000
  const now = new Date()
  
  for (let i = 365; i >= 0; i--) {
    const date = new Date(now)
    date.setDate(date.getDate() - i)
    const randomFactor = 1 + (Math.random() - 0.4) * 0.02
    const trendFactor = 1 + (365 - i) * 0.0003
    const value = baseValue * trendFactor * randomFactor
    data.push({
      date: date.toISOString().split('T')[0],
      value: Math.round(value * 100) / 100
    })
  }
  
  return data
}

const mockAssets: Asset[] = [
  {
    id: '1',
    ticker: 'PETR4',
    name: 'Petrobras PN',
    type: 'stock',
    quantity: 200,
    averagePrice: 32.50,
    currentPrice: 38.45,
    totalInvested: 6500,
    currentValue: 7690,
    profitLoss: 1190,
    percentChange: 18.31
  },
  {
    id: '2',
    ticker: 'VALE3',
    name: 'Vale ON',
    type: 'stock',
    quantity: 150,
    averagePrice: 68.00,
    currentPrice: 72.30,
    totalInvested: 10200,
    currentValue: 10845,
    profitLoss: 645,
    percentChange: 6.32
  },
  {
    id: '3',
    ticker: 'ITUB4',
    name: 'Itaú Unibanco PN',
    type: 'stock',
    quantity: 300,
    averagePrice: 28.50,
    currentPrice: 31.20,
    totalInvested: 8550,
    currentValue: 9360,
    profitLoss: 810,
    percentChange: 9.47
  },
  {
    id: '4',
    ticker: 'BOVA11',
    name: 'iShares Ibovespa',
    type: 'etf',
    quantity: 100,
    averagePrice: 112.00,
    currentPrice: 118.50,
    totalInvested: 11200,
    currentValue: 11850,
    profitLoss: 650,
    percentChange: 5.80
  },
  {
    id: '5',
    ticker: 'IVVB11',
    name: 'iShares S&P 500',
    type: 'etf',
    quantity: 80,
    averagePrice: 265.00,
    currentPrice: 285.00,
    totalInvested: 21200,
    currentValue: 22800,
    profitLoss: 1600,
    percentChange: 7.55
  },
  {
    id: '6',
    ticker: 'MXRF11',
    name: 'Maxi Renda FII',
    type: 'fii',
    quantity: 500,
    averagePrice: 10.20,
    currentPrice: 10.85,
    totalInvested: 5100,
    currentValue: 5425,
    profitLoss: 325,
    percentChange: 6.37
  },
  {
    id: '7',
    ticker: 'XPLG11',
    name: 'XP Log FII',
    type: 'fii',
    quantity: 200,
    averagePrice: 98.50,
    currentPrice: 102.30,
    totalInvested: 19700,
    currentValue: 20460,
    profitLoss: 760,
    percentChange: 3.86
  },
  {
    id: '8',
    ticker: 'BTC',
    name: 'Bitcoin',
    type: 'crypto',
    quantity: 0.15,
    averagePrice: 280000,
    currentPrice: 320000,
    totalInvested: 42000,
    currentValue: 48000,
    profitLoss: 6000,
    percentChange: 14.29
  },
  {
    id: '9',
    ticker: 'ETH',
    name: 'Ethereum',
    type: 'crypto',
    quantity: 2.5,
    averagePrice: 9800,
    currentPrice: 11200,
    totalInvested: 24500,
    currentValue: 28000,
    profitLoss: 3500,
    percentChange: 14.29
  },
  {
    id: '10',
    ticker: 'CDB-150',
    name: 'CDB Banco XYZ 150% CDI',
    type: 'fixed',
    quantity: 1,
    averagePrice: 15000,
    currentPrice: 16250,
    totalInvested: 15000,
    currentValue: 16250,
    profitLoss: 1250,
    percentChange: 8.33
  }
]

const mockTransactions: Transaction[] = [
  {
    id: '1',
    type: 'buy',
    ticker: 'PETR4',
    assetType: 'stock',
    amount: 3245,
    quantity: 100,
    price: 32.45,
    date: '2024-01-15T10:30:00',
    status: 'success'
  },
  {
    id: '2',
    type: 'dividend',
    ticker: 'MXRF11',
    assetType: 'fii',
    amount: 125.50,
    date: '2024-01-14T00:00:00',
    status: 'success'
  },
  {
    id: '3',
    type: 'deposit',
    amount: 5000,
    date: '2024-01-12T14:20:00',
    status: 'success'
  },
  {
    id: '4',
    type: 'buy',
    ticker: 'IVVB11',
    assetType: 'etf',
    amount: 5650,
    quantity: 20,
    price: 282.50,
    date: '2024-01-10T11:45:00',
    status: 'success'
  },
  {
    id: '5',
    type: 'sell',
    ticker: 'BBAS3',
    assetType: 'stock',
    amount: 2850,
    quantity: 50,
    price: 57.00,
    date: '2024-01-08T15:30:00',
    status: 'success'
  },
  {
    id: '6',
    type: 'dividend',
    ticker: 'ITUB4',
    assetType: 'stock',
    amount: 89.40,
    date: '2024-01-05T00:00:00',
    status: 'success'
  },
  {
    id: '7',
    type: 'buy',
    ticker: 'BTC',
    assetType: 'crypto',
    amount: 15000,
    quantity: 0.05,
    price: 300000,
    date: '2024-01-03T09:15:00',
    status: 'pending'
  },
  {
    id: '8',
    type: 'withdraw',
    amount: 2000,
    date: '2024-01-02T16:00:00',
    status: 'success'
  }
]

const calculateAllocations = (assets: Asset[]): PortfolioAllocation[] => {
  const totalValue = assets.reduce((sum, asset) => sum + asset.currentValue, 0)
  
  const groupedByType = assets.reduce((acc, asset) => {
    if (!acc[asset.type]) {
      acc[asset.type] = { totalInvested: 0, currentValue: 0 }
    }
    acc[asset.type].totalInvested += asset.totalInvested
    acc[asset.type].currentValue += asset.currentValue
    return acc
  }, {} as Record<string, { totalInvested: number; currentValue: number }>)

  const typeLabels: Record<string, string> = {
    stock: 'Ações',
    etf: 'ETFs',
    fii: 'FIIs',
    crypto: 'Cripto',
    fixed: 'Renda Fixa'
  }

  return Object.entries(groupedByType).map(([type, values]) => ({
    type: type as Asset['type'],
    label: typeLabels[type] || type,
    totalInvested: values.totalInvested,
    currentValue: values.currentValue,
    percentage: (values.currentValue / totalValue) * 100
  })).sort((a, b) => b.percentage - a.percentage)
}

export const fetchPortfolioData = async (): Promise<PortfolioData> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 800))

  const totalBalance = mockAssets.reduce((sum, asset) => sum + asset.currentValue, 0)
  const totalInvested = mockAssets.reduce((sum, asset) => sum + asset.totalInvested, 0)
  const profitLoss = totalBalance - totalInvested
  const percentChange = (profitLoss / totalInvested) * 100

  return {
    totalBalance,
    totalInvested,
    profitLoss,
    percentChange,
    assets: mockAssets,
    transactions: mockTransactions,
    allocations: calculateAllocations(mockAssets),
    historicalData: generateHistoricalData()
  }
}
