'use client'

import { useState, useMemo } from 'react'
import { 
  ArrowUpDown, 
  Search, 
  TrendingUp, 
  TrendingDown,
  ChevronDown,
  ChevronUp
} from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from '@/components/ui/table'
import { cn } from '@/lib/utils'
import type { Asset } from '@/lib/types'
import { assetTypeLabels } from '@/lib/types'

interface HoldingsTableProps {
  assets: Asset[]
  isLoading?: boolean
}

type SortField = 'ticker' | 'currentValue' | 'profitLoss' | 'percentChange'
type SortDirection = 'asc' | 'desc'

export function HoldingsTable({ assets, isLoading }: HoldingsTableProps) {
  const [searchQuery, setSearchQuery] = useState('')
  const [sortField, setSortField] = useState<SortField>('currentValue')
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc')
  const [expandedRows, setExpandedRows] = useState<Set<string>>(new Set())

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value)
  }

  const formatPercent = (value: number) => {
    return `${value >= 0 ? '+' : ''}${value.toFixed(2)}%`
  }

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc')
    } else {
      setSortField(field)
      setSortDirection('desc')
    }
  }

  const toggleRowExpand = (id: string) => {
    const newExpanded = new Set(expandedRows)
    if (newExpanded.has(id)) {
      newExpanded.delete(id)
    } else {
      newExpanded.add(id)
    }
    setExpandedRows(newExpanded)
  }

  const filteredAndSortedAssets = useMemo(() => {
    let filtered = assets.filter(
      asset =>
        asset.ticker.toLowerCase().includes(searchQuery.toLowerCase()) ||
        asset.name.toLowerCase().includes(searchQuery.toLowerCase())
    )

    filtered.sort((a, b) => {
      const aValue = a[sortField]
      const bValue = b[sortField]
      
      if (typeof aValue === 'string' && typeof bValue === 'string') {
        return sortDirection === 'asc' 
          ? aValue.localeCompare(bValue)
          : bValue.localeCompare(aValue)
      }
      
      return sortDirection === 'asc' 
        ? (aValue as number) - (bValue as number)
        : (bValue as number) - (aValue as number)
    })

    return filtered
  }, [assets, searchQuery, sortField, sortDirection])

  const getTypeBadgeColor = (type: Asset['type']) => {
    const colors = {
      stock: 'bg-primary/10 text-primary border-primary/20',
      etf: 'bg-accent text-accent-foreground border-accent-foreground/20',
      fii: 'bg-amber-50 text-amber-700 border-amber-200',
      crypto: 'bg-purple-50 text-purple-700 border-purple-200',
      fixed: 'bg-slate-50 text-slate-700 border-slate-200'
    }
    return colors[type]
  }

  const SortIcon = ({ field }: { field: SortField }) => {
    if (sortField !== field) {
      return <ArrowUpDown className="h-3.5 w-3.5 text-muted-foreground/50" />
    }
    return sortDirection === 'asc' 
      ? <ChevronUp className="h-3.5 w-3.5 text-primary" />
      : <ChevronDown className="h-3.5 w-3.5 text-primary" />
  }

  if (isLoading) {
    return (
      <Card className="border-border/50 shadow-sm">
        <CardHeader className="pb-4">
          <Skeleton className="h-6 w-40" />
          <Skeleton className="h-10 w-full mt-4" />
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[1, 2, 3, 4, 5].map((i) => (
              <Skeleton key={i} className="h-14 w-full" />
            ))}
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="border-border/50 shadow-sm hover:shadow-md transition-shadow duration-300">
      <CardHeader className="pb-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <CardTitle className="text-lg font-semibold text-accent-foreground">
            Meus Ativos
          </CardTitle>
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar ativo..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 bg-secondary/30 border-border/50 focus:border-primary/50"
            />
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {/* Desktop Table */}
        <div className="hidden lg:block overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="border-border/50 hover:bg-transparent">
                <TableHead className="w-[180px]">
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="h-auto p-0 font-semibold text-muted-foreground hover:text-foreground"
                    onClick={() => handleSort('ticker')}
                  >
                    Ativo <SortIcon field="ticker" />
                  </Button>
                </TableHead>
                <TableHead className="text-center">Tipo</TableHead>
                <TableHead className="text-right">Qtd</TableHead>
                <TableHead className="text-right">PM</TableHead>
                <TableHead className="text-right">Atual</TableHead>
                <TableHead className="text-right">
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="h-auto p-0 font-semibold text-muted-foreground hover:text-foreground ml-auto"
                    onClick={() => handleSort('currentValue')}
                  >
                    Valor <SortIcon field="currentValue" />
                  </Button>
                </TableHead>
                <TableHead className="text-right">
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="h-auto p-0 font-semibold text-muted-foreground hover:text-foreground ml-auto"
                    onClick={() => handleSort('profitLoss')}
                  >
                    Lucro/Prejuízo <SortIcon field="profitLoss" />
                  </Button>
                </TableHead>
                <TableHead className="text-right">
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="h-auto p-0 font-semibold text-muted-foreground hover:text-foreground ml-auto"
                    onClick={() => handleSort('percentChange')}
                  >
                    Variação <SortIcon field="percentChange" />
                  </Button>
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredAndSortedAssets.map((asset) => (
                <TableRow 
                  key={asset.id} 
                  className="border-border/30 hover:bg-secondary/30 transition-colors"
                >
                  <TableCell>
                    <div className="flex flex-col">
                      <span className="font-semibold text-foreground font-mono">
                        {asset.ticker}
                      </span>
                      <span className="text-xs text-muted-foreground truncate max-w-[150px]">
                        {asset.name}
                      </span>
                    </div>
                  </TableCell>
                  <TableCell className="text-center">
                    <Badge 
                      variant="outline" 
                      className={cn('text-xs', getTypeBadgeColor(asset.type))}
                    >
                      {assetTypeLabels[asset.type]}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right font-mono text-sm">
                    {asset.quantity.toLocaleString('pt-BR', { 
                      minimumFractionDigits: asset.type === 'crypto' ? 4 : 0,
                      maximumFractionDigits: asset.type === 'crypto' ? 4 : 0
                    })}
                  </TableCell>
                  <TableCell className="text-right font-mono text-sm text-muted-foreground">
                    {formatCurrency(asset.averagePrice)}
                  </TableCell>
                  <TableCell className="text-right font-mono text-sm">
                    {formatCurrency(asset.currentPrice)}
                  </TableCell>
                  <TableCell className="text-right font-semibold">
                    {formatCurrency(asset.currentValue)}
                  </TableCell>
                  <TableCell className="text-right">
                    <span className={cn(
                      'font-semibold',
                      asset.profitLoss >= 0 ? 'text-emerald-600' : 'text-red-600'
                    )}>
                      {formatCurrency(asset.profitLoss)}
                    </span>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className={cn(
                      'inline-flex items-center gap-1 px-2 py-1 rounded-full text-sm font-medium',
                      asset.percentChange >= 0 
                        ? 'bg-emerald-50 text-emerald-700' 
                        : 'bg-red-50 text-red-700'
                    )}>
                      {asset.percentChange >= 0 
                        ? <TrendingUp className="h-3.5 w-3.5" />
                        : <TrendingDown className="h-3.5 w-3.5" />
                      }
                      {formatPercent(asset.percentChange)}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        {/* Mobile Cards */}
        <div className="lg:hidden space-y-3">
          {filteredAndSortedAssets.map((asset) => (
            <div
              key={asset.id}
              className="p-4 rounded-xl bg-secondary/30 border border-border/30"
            >
              <button
                className="w-full text-left"
                onClick={() => toggleRowExpand(asset.id)}
              >
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div>
                      <span className="font-semibold text-foreground font-mono text-lg">
                        {asset.ticker}
                      </span>
                      <Badge 
                        variant="outline" 
                        className={cn('text-xs ml-2', getTypeBadgeColor(asset.type))}
                      >
                        {assetTypeLabels[asset.type]}
                      </Badge>
                    </div>
                  </div>
                  {expandedRows.has(asset.id) ? (
                    <ChevronUp className="h-4 w-4 text-muted-foreground" />
                  ) : (
                    <ChevronDown className="h-4 w-4 text-muted-foreground" />
                  )}
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-muted-foreground">Valor atual</p>
                    <p className="font-semibold text-foreground">
                      {formatCurrency(asset.currentValue)}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-muted-foreground">Variação</p>
                    <div className={cn(
                      'inline-flex items-center gap-1 text-sm font-medium',
                      asset.percentChange >= 0 ? 'text-emerald-600' : 'text-red-600'
                    )}>
                      {asset.percentChange >= 0 
                        ? <TrendingUp className="h-3.5 w-3.5" />
                        : <TrendingDown className="h-3.5 w-3.5" />
                      }
                      {formatPercent(asset.percentChange)}
                    </div>
                  </div>
                </div>
              </button>

              {expandedRows.has(asset.id) && (
                <div className="mt-4 pt-4 border-t border-border/30 grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <p className="text-xs text-muted-foreground">Quantidade</p>
                    <p className="font-mono">{asset.quantity.toLocaleString('pt-BR')}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Preço Médio</p>
                    <p className="font-mono">{formatCurrency(asset.averagePrice)}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Preço Atual</p>
                    <p className="font-mono">{formatCurrency(asset.currentPrice)}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Lucro/Prejuízo</p>
                    <p className={cn(
                      'font-semibold',
                      asset.profitLoss >= 0 ? 'text-emerald-600' : 'text-red-600'
                    )}>
                      {formatCurrency(asset.profitLoss)}
                    </p>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        {filteredAndSortedAssets.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground">Nenhum ativo encontrado</p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
