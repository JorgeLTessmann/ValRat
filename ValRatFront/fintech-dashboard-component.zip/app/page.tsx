'use client'

import useSWR from 'swr'
import {
  DashboardHeader,
  WalletCard,
  AssetAllocation,
  QuickActions,
  TransactionLedger,
  HoldingsTable,
  StatsGrid,
  EmptyState
} from '@/components/dashboard'
import { fetchPortfolioData } from '@/lib/api'

export default function DashboardPage() {
  const { data: portfolio, isLoading } = useSWR(
    'portfolio',
    fetchPortfolioData,
    {
      refreshInterval: 60000, // Refresh every minute
      revalidateOnFocus: true
    }
  )

  const hasInvestments = portfolio && portfolio.assets.length > 0

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <DashboardHeader userName="Pedro" />

        {/* Stats Overview */}
        <div className="mb-8">
          <StatsGrid
            totalBalance={portfolio?.totalBalance ?? 0}
            totalInvested={portfolio?.totalInvested ?? 0}
            profitLoss={portfolio?.profitLoss ?? 0}
            percentChange={portfolio?.percentChange ?? 0}
            isLoading={isLoading}
          />
        </div>

        {!isLoading && !hasInvestments ? (
          <EmptyState onAddInvestment={() => console.log('[v0] Add investment clicked')} />
        ) : (
          <>
            {/* Main Content Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
              {/* Wallet Card - Takes 2 columns */}
              <div className="lg:col-span-2">
                <WalletCard
                  totalBalance={portfolio?.totalBalance ?? 0}
                  profitLoss={portfolio?.profitLoss ?? 0}
                  percentChange={portfolio?.percentChange ?? 0}
                  historicalData={portfolio?.historicalData ?? []}
                  isLoading={isLoading}
                />
              </div>

              {/* Quick Actions */}
              <div className="lg:col-span-1">
                <QuickActions />
              </div>
            </div>

            {/* Second Row */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
              {/* Asset Allocation */}
              <div className="lg:col-span-1">
                <AssetAllocation
                  allocations={portfolio?.allocations ?? []}
                  isLoading={isLoading}
                />
              </div>

              {/* Transaction Ledger - Takes 2 columns */}
              <div className="lg:col-span-2">
                <TransactionLedger
                  transactions={portfolio?.transactions ?? []}
                  isLoading={isLoading}
                />
              </div>
            </div>

            {/* Holdings Table - Full Width */}
            <div className="mb-8">
              <HoldingsTable
                assets={portfolio?.assets ?? []}
                isLoading={isLoading}
              />
            </div>
          </>
        )}

        {/* Footer */}
        <footer className="mt-12 pt-8 border-t border-border/50">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <span className="font-bold text-primary">val</span>
              <span className="font-bold text-foreground">Rat</span>
              <span>© 2024</span>
            </div>
            <p className="text-center sm:text-right">
              Dados de mercado podem ter atraso. Não é recomendação de investimento.
            </p>
          </div>
        </footer>
      </div>
    </div>
  )
}
